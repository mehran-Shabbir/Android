package com.example.gridviewsolo008;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
public class MainActivity extends Activity implements OnItemClickListener {
    TextView tvMsg;
    GridView gridview;
    TextView tvSoloMsg;
    Integer[] mThumbIds;
    ImageView ivSoloPicture;
    Button btnBack;
    Bundle myMemoryBundle;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myMemoryBundle = savedInstanceState;
        setContentView(R.layout.activity_main);
        tvMsg = (TextView )findViewById(R.id.tvMsg);
//initialize array of images with a few pictures
        mThumbIds = new Integer[] {
                R.drawable.gallery_photo_1, R.drawable.gallery_photo_2,
                R.drawable.gallery_photo_3, R.drawable.gallery_photo_4,
                R.drawable.gallery_photo_5, R.drawable.gallery_photo_6,
                R.drawable.gallery_photo_7, R.drawable.gallery_photo_8
        };
        gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new ImageAdapter(this));
        gridview.setOnItemClickListener(this);
    }
    public class ImageAdapter extends BaseAdapter {
        private Context mContext;
        public ImageAdapter(Context c) {
            mContext = c;
        }
        public int getCount() {
            return mThumbIds.length;
        }
        @SuppressLint("WrongConstant")
        public Object getItem(int position) {
            Toast.makeText(getApplicationContext(), "Pos: " + position, 1).show();
            return null;
        }
        public long getItemId(int position) {
            return 0;
        }
        // create a new ImageView for each item referenced by the Adapter
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
// if it's not recycled, initialize some attributes
                imageView = new ImageView(mContext);
                imageView.setLayoutParams(new GridView.LayoutParams(85, 85));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setPadding(8, 8, 8, 8); }
            else {
                imageView = (ImageView) convertView;
            }
            imageView.setImageResource(mThumbIds[position]);
            return imageView;
        }
    }
    @Override
    public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
        tvMsg.setText("Position: " + position +
                " R.drawable.gallery_photo_" + (position+1) );
// show selected picture in an individual view
        showScreen2(position);
    }
    //////////////////////////////////////////////////////////////////////////
    private void showScreen2(int position){
// show the selected picture as a single frame
        setContentView(R.layout.solo_picture);
        tvSoloMsg = (TextView) findViewById(R.id.tvSoloMsg);
        ivSoloPicture = (ImageView) findViewById(R.id.imgSoloPhoto);
        tvSoloMsg.setText("image " + position);
        ivSoloPicture.setImageResource(mThumbIds[position]);
        btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
// redraw the main screen beginning the whole app.
                onCreate(myMemoryBundle);
            }
        });
    }//showScreen2
//////////////////////////////////////////////////////////////////////////
}